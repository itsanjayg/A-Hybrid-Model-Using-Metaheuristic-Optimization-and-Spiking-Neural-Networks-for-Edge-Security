# A Hybrid Model Using Metaheuristic Optimization and Spiking Neural Networks for Edge Security

Official PyTorch and SNN implementation for the paper **"A Hybrid Model Using Metaheuristic Optimization and Spiking Neural Networks for Edge Security"**.

## Overview
With the rapid proliferation of Internet of Things (IoT) ecosystems, securing battery-powered and resource-constrained edge gateways against cyber-attacks requires ultra-low-power, real-time Intrusion Detection Systems (IDS). This framework proposes a **bi-level hybrid learning architecture**:
1. **Latency Spike Encoding (Eq. 1):** Converts normalized continuous network traffic features into sparse time-to-first-spike binary trains.
2. **Inner Loop (Surrogate Gradient SNN, Eqs. 2–3):** Trains synaptic weights $W_l$ of Leaky Integrate-and-Fire (LIF) layers using arctangent surrogate backpropagation and Focal Loss.
3. **Outer Loop (Adaptive Hybrid Metaheuristic Optimization, Eqs. 4–5):** Optimizes layer-wise firing thresholds ($V_{th,l}$), membrane decay constants ($\beta_l$), and binary synaptic pruning masks ($M_l$) via a hardware-aware multi-objective fitness function:
   $$F(X_k) = 0.70(1 - F1_{\text{macro}}) + 0.15 R_{\text{spike}} + 0.15(1 - \text{Sparsity})$$

## Repository Structure
- `hybrid_snn_edge_security.py`: Standalone end-to-end Python script covering data preprocessing, latency encoding, inner/outer bi-level optimization, baseline comparisons (RF, XGBoost, 1D-CNN, MLP, Fixed-SNN, PSO-SNN, GWO-SNN), 45nm CMOS energy profiling, and 300-DPI figure generation.
- `Hybrid_Metaheuristic_SNN_Edge_Security.ipynb`: Ready-to-run Google Colab / Jupyter Notebook version with cell-by-cell execution.
- `requirements.txt`: Required Python packages.

## Supported Datasets
- **CICIoT2023:** [UNB CICIoT2023 Dataset](https://www.unb.ca/cic/datasets/iotdataset-2023.html)
- **Edge-IIoTset:** [Edge-IIoTset Repository](https://www.kaggle.com/datasets/mohamedamineferrag/edgeiiotset-cyber-security-dataset-of-iot-iiot)

*(Note: By default, `USE_REAL_CSV = False` runs an immediate realistic imbalanced IoT benchmark simulation. Set `USE_REAL_CSV = True` and point `CSV_PATH` to your downloaded dataset CSV to train on raw packet flows.)*

## Quick Start
```bash
pip install -r requirements.txt
python hybrid_snn_edge_security.py
```
